package Zoo;

public class Roka extends Animal{
	
	Roka(String name){
		super(name);
	}

	
	public String hangotad() {
		
		return "what does the fox say?";
	}
	public String megharapjak() {
		return hangotad();
	}
	
}
