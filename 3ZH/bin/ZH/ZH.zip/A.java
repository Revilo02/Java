package ZH;

public  class A {
	void foo() {System.out.println("A");}
	void bar() {foo();}
	void qus() {bar();}
}
