package ZH;

public class Main {
	static public void main(String[] args) {
		/*
		 * Szia!
		 * Gondold �t hogy mire mit �rna ki miut�n megn�zed a m�sik h�rom v�laszlehet�s�get
		 * Ilyesmi lesz a ZH ugyhogy mindenk�pp fontos lenne hogy �rtsd hogy mit mi�rt 
		 * ha valamelyik nem vil�gos akkor nyugodtan k�rdezz �s elmondom
		 * �s egy�l a h�tv�g�n sok csokit
		 * �s thanks for fizika :D
		 */
		A a=new C();
//		a.foo();
//		a.qus();
//		a.bar();
	
		B c=new C();
//		c.foo();
//		c.qus();
//		c.foo();
		
		A b=new B();
//		b.foo();
//		b.bar();
//		b.qus();
		
		A d=new A();
//		d.foo();
//		d.bar();
//		d.qus();
	}
}
