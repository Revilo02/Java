package ZH;

public class C extends B{
	void foo() {System.out.println("C");}
	void bar() {foo();}
	void qus() {super.foo();}
}
