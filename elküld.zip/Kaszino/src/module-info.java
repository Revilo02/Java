module Kaszino {
}