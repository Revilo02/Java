package ZH;

public class Main {
	static public void main(String[] args) {
		A a=new B();
		a.foo();
		a.bar();
		a.qus();
	}
}
