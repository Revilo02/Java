package K�nyvt�r_nyilv�ntart�Tests;

import static org.junit.Assert.*;

import org.junit.Test;

public class JUnitTest  {
	@Before
		public void setUP() throws Exception{
		
	}
	@After
	public void teardown() throws Exception{
		
	}
	@Test
	public final void test() {
		fail("Not yet implemented"); // TODO
	}

	@Test
    public void test_JUnit() {
        System.out.println("This is the testcase in this class");
        String str1="This is the testcase in this class";
        assertEquals("This is the testcase in this class", str1);
    }
	 public void testAdd(){
	      double result = value1 + value2;
	      assertTrue(result == 6);
	 }
}
