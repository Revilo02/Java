package K�nyvt�r_nyilv�ntart�;

public class NotOwnerException extends Exception {
	  public String getMessage() {
	    	return "Nem birtokol k�nyvet";
	    }
	    
}
