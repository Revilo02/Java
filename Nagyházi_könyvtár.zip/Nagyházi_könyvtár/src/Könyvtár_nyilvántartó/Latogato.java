package K�nyvt�r_nyilv�ntart�;
import java.util.ArrayList;
public class Latogato {
	private String name;
	private String elerhetoseg;
	private  ArrayList<K�nyvek> a=new ArrayList<K�nyvek>();
	private int ID;
	static private int IDplusz;
	Latogato(String n,String e){
		name=n;
		elerhetoseg=e;
		ID=++IDplusz;
		
	}
	public String getName() {return name;}
	public String getElerhetoseg() {return elerhetoseg;}
	public int getID() {return ID;}
	public ArrayList<K�nyvek> getElvitt(){return a;}
	public String toString() {return "Az olvas� neve: "+name+"\n"+"Az olvas� el�rhet�s�ge:"+elerhetoseg;}
	public void namemodosit(String n) {name=n;}
	public void elerhetosegmodosit(String e) {elerhetoseg=e;}
	public void konyvadd(K�nyvek k) {
			a.add(k);		
	}
	public ArrayList<K�nyvek> listaz(){
		return a;
	}
}
