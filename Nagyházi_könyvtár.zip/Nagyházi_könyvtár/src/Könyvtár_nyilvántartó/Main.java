package K�nyvt�r_nyilv�ntart�;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.io.*;
public class Main extends IO{
	
	static public void main(String[] args) throws Exception {
		try{beolvas();}catch ( FileNotFoundException e) {
			  System.err.println(e.getMessage());}
		//sArrayList<K�nyvek> books=new ArrayList<K�nyvek>();
		books.add(new Tudomanyos("K�nyvekk","�g",1,"B�luka"));
		books.add(new Irodalmi("Qwert","�g",1,"B�luska"));
		books.get(1).setKiadva(true);
		latogatok.add(new Latogato("L�szl� Oliv�r","A s�rk�ve"));
		latogatok.add(new Latogato("L�szl� Oliv�r2","Nem a s�rk�ve"));
		latogatok.get(1).listaz().add(books.get(1));
		for(int i=0;i<books.size();i++) {
			//System.out.println(books.get(i));
		}
		System.out.println(books.size());
		Scanner sc=new Scanner(System.in);
		//String cmd = bf.readLine();	
		
		//boolean a=books.get(0).getClass().equals(Irodalmi i);
		System.out.println(books.get(0).getClass());
		while(true) {
			Fomenu();
			String cmd = sc.nextLine();
			
			if(cmd.equals("9")) {
				sc.close();
				break;
			} else if(cmd.equals("0")) {
				bookaddmenu();
				Letrehoz(books);
			} else if(cmd.equals("1")) {
				try{DeleteBook();}
				catch (BookNotFoundException e) {
					  System.err.println(e.getMessage());}
				catch (IDNotFoundException e) {
					System.err.println(e.getMessage());
				}
			} else if(cmd.equals("2")) {
				try{Bookmodify();}
				catch (BookNotFoundException e) {
					  System.err.println(e.getMessage());
				}catch (IDNotFoundException e) {
					System.err.println(e.getMessage());
				}
			} else if(cmd.equals("3")) {
				try{KonyvKiad();}
				catch (BookNotFoundException e) {
					  System.err.println(e.getMessage());}
				catch (IDNotFoundException e) {
					System.err.println(e.getMessage());
				}
				catch (ReaderNotFoundException e) {
					  System.err.println(e.getMessage());}
				catch (ReaderIDNotFoundException e) {
					  System.err.println(e.getMessage());}
			}else if(cmd.equals("4")) {
				try{KonyvVisszavesz();}
				catch (NotOwnerException e) {
					  System.err.println(e.getMessage());}
			}else if(cmd.equals("5")){
				try{Booksearch();}
				catch (BookNotFoundException e) {
					  System.err.println(e.getMessage());}
			}else if(cmd.equals("6")){
				OlvasoLetrehoz();
			}else if(cmd.equals("7")){
				try{Olvasomodify();}
				catch (ReaderNotFoundException e) {
					  System.err.println(e.getMessage());}
				catch (ReaderIDNotFoundException e) {
					  System.err.println(e.getMessage());}
			}else if(cmd.equals("8")){
				Collections.sort(books, new IDComparator());	

			}
			System.out.println();
		}

		
	}
}


