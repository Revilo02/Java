package K�nyvt�r_nyilv�ntart�;

public class Irodalmi extends K�nyvek {
	String mufaj;
	Irodalmi(String name, String szerzo, int kiadaseve,  String mufaj) {
		super(name, szerzo, kiadaseve);
		this.mufaj=mufaj;
		type="i";
	}
	public String getMufaj() {return mufaj;}
	public void setMufaj(String s) {mufaj=s;}
	public String toString() {
		return super.toString()+", "+mufaj;
	}
	//K�s�bbi adattagm�dos�t�sokhoz a Setter met�dusok itt lesznek
	
}
