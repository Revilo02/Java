package K�nyvt�r_nyilv�ntart�;

public class BookNotFoundException extends Exception{
	String s;
	BookNotFoundException(String s ){
	this.s=s;
	}
    public String getMessage() {
    	return "Ilyen c�mmel k�nyv nem tal�lhat�";
    }
    
}
