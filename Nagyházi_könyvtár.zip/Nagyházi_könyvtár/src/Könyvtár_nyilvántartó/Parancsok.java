package K�nyvt�r_nyilv�ntart�;

import java.io.*;
import java.util.*;


public class Parancsok extends Menu{
	
	//Nem szereti a program ha itt SC.close-t haszn�lok mert akkor a main.java-ban hiba keletkezik
	
	
	//K�nyvek t�rl�se ami kisz�ri azt ha a felhaszn�l� olyanra keres ami nem l�tezik -->vissza a f�men�be ,ha rossz ID-t ad meg --> vissza a f�men�be
	//J� ID-t ad meg �s benne van a felsorol�sba -->sikeres t�rl�s
	
	
	
	protected static boolean elerhetoKonyv(K�nyvek k) {
		
		if (k.getKiadva()==true)
			return false;
		else return true;
	}
	protected static int kiadhato() throws BookNotFoundException, IDNotFoundException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Adja meg a kivenni k�v�nt k�nyv c�m�t: ");
		String kivesz=sc.nextLine();
		int cnt=0;
		for(int i=0;i<books.size();i++) {
			if(books.get(i).getName().contains(kivesz) & elerhetoKonyv(books.get(i))) {
				cnt++;
				System.out.println(books.get(i));
			}
		}
		if(cnt==0)throw new BookNotFoundException(kivesz);
		else {
			int kiadID=sc.nextInt();
			for(int i=0;i<books.size();i++) {
				if(books.get(i).getName().contains(kivesz) & elerhetoKonyv(books.get(i)) &kiadID==books.get(i).getID()) {
					return kiadID;
				}
			}throw new IDNotFoundException(kiadID);
		}
	}
	
	protected static void KonyvVisszavesz() throws Exception {
		Scanner sc=new Scanner(System.in);
		System.out.println("Adja meg az olvas�nak a nev�t aki k�nyvet hozott vissza: ");
		int sv=OlvasoSearch();
		int i=0;
		for( i=0;i<latogatok.size();i++) {
			if(latogatok.get(i).getID()==sv ) {
				
				break;
			}
	
		}
		if (latogatok.get(i).listaz().size()==0) {
			throw new NotOwnerException();
		}else {
			for(int j=0;j<latogatok.get(i).listaz().size();j++) {
				System.out.println(latogatok.get(i).listaz().get(j));
			}
			System.out.println("Adja meg a visszahozni k�v�nt k�nyv ID-j�t");
			int id=sc.nextInt();
			for(int j=0;j<latogatok.get(i).listaz().size();j++) {
				latogatok.get(i).listaz().get(j).setKiadva(false);
				latogatok.get(i).listaz().remove(j);
			}
			System.out.println("Sikeres k�nyv visszav�tel");
			
			//return;
		}
	
}
	protected static void KonyvKiad() throws Exception {
		int kiad=kiadhato();
		System.out.println("Adja meg az olvas� nev�t aki ki k�v�nja venni a k�nyvet: ");
		int vevo=OlvasoSearch();
		for(int i=0;i<latogatok.size();i++) {
			if(latogatok.get(i).getID()==vevo ) {
				for(int j=0; j<books.size();j++) {
					if(books.get(j).getID()==kiad) {
						books.get(j).setKiadva(true);
						latogatok.get(i).konyvadd(books.get(j));;
				}
			}
		}
	}
}	
	
	
	
	
	protected static void OlvasoLetrehoz() {
		Scanner sc=new Scanner(System.in);
		System.out.println("K�rem adja meg az olvas� TELJES nev�t: ");
		String nev=sc.nextLine();
		System.out.println("K�rem adja meg az olvas� el�rhet�s�g�t:");
		String elerh=sc.nextLine();
		latogatok.add(new Latogato(nev,elerh));
		System.out.println("Olvas� sikeresen hozz�adva");
	}
	protected static int OlvasoSearch() throws Exception {
		Scanner sc=new Scanner(System.in);
		int cnt=0;
		String nev=sc.nextLine();
		for(int i=0; i<latogatok.size();i++) {
			if(latogatok.get(i).getName().contains(nev)) {
				System.out.println(latogatok.get(i).getID()+" "+latogatok.get(i));
				cnt++;
			}
		}
		if (cnt==0) {
			throw new ReaderNotFoundException();
		}
		int id=sc.nextInt();
		for(int i=0; i<latogatok.size();i++) {
			if(latogatok.get(i).getName().contains(nev)  & latogatok.get(i).getID()==id) {
				return id;
			}
		}throw new ReaderIDNotFoundException();
	}
	protected static void Olvasomodify() throws Exception {
		Scanner sc=new Scanner(System.in);
		System.out.println("K�rem adja meg a m�dos�tani k�v�nt olvas� nev�t: ");
		int a=OlvasoSearch();
		System.out.println("K�rem v�lasszon az al�bbi men�pontok k�z�l: ");
		readermodify();
		while (true) {
			String cmd=sc.nextLine();
			
			if(cmd.equals("1")) {
				System.out.println("Adja meg az olvas� �j nev�t");
				String ujnev=sc.nextLine();
				latogatok.get(a).namemodosit(ujnev);
				System.out.println("Sikeres m�dos�t�s");
				break;
			}else if(cmd.equals("2")) {
				System.out.println("Adja meg az olvas� �j el�rhet�s�g�t");
				String ujelerh=sc.nextLine();
				latogatok.get(a).elerhetosegmodosit(ujelerh);
				System.out.println("Sikeres m�dos�t�s");
				break;
			}else if(cmd.equals("3")) {
				System.out.println("Adja meg az olvas� �j nev�t");
				String ujnev=sc.nextLine();
				latogatok.get(a).namemodosit(ujnev);
				System.out.println("Adja meg az olvas� �j el�rhet�s�g�t");
				String ujelerh=sc.nextLine();
				latogatok.get(a).elerhetosegmodosit(ujelerh);
				break;
			}else if(cmd.equals(4)) {
				break;
			}
		}
	}
	protected static void sablon() {
		System.out.println("ID , c�m, szerz�, kiadva");
	}
	protected static void DeleteBook() throws Exception {
		int cnt=0;
		System.out.println("�rja be a t�r�lni k�v�nt k�nyv c�m�t");
		Scanner sc=new Scanner(System.in);
		String cim=sc.nextLine();
		sablon();
		for(int i=0;i<books.size();i++) {
		
			if(books.get(i).getName().contains(cim)) {
				cnt++;
				System.out.println(books.get(i));
			}
		}
		if(cnt==0) {
			throw new BookNotFoundException(cim);
			//System.out.println("Nincs tal�lat vissza ir�nytottuk   a f�men�be");
		}else {
			int torol=sc.nextInt();
			
			System.out.println("Adja meg a t�r�lni k�v�nt k�nyv ID-j�t");
			keres(torol,cim);
			books.remove(keres(torol,cim));
			System.out.println("Sikeres t�rl�s");
			}
		}
	
	static int keres(int talalat,String cim) throws Exception{
		for(int i=0;i<books.size();i++) {
			if(books.get(i).getID()==talalat &books.get(i).getName().contains(cim) &elerhetoKonyv(books.get(i))) {
				return i;
			}	
		}throw new IDNotFoundException(talalat);
		//	return -1;
	}
	protected static void Bookmodify() throws Exception{
		Scanner sc=new Scanner(System.in);
		System.out.println("Adja meg a m�dos�tani k�v�nt k�nyv c�m�t");
		String cim=sc.nextLine() ;
		int cnt=0;
		for(int i=0;i<books.size();i++) {
			if(books.get(i).getName().contains(cim)) {
				cnt++;
				System.out.println(books.get(i));
			}
		}
		if(cnt==0) {
			throw new BookNotFoundException(cim);
		}else {
			System.out.println("Adja meg a k�nyv ID-j�t");
			int talalat=sc.nextInt();
			int a=keres(talalat,cim);
			bookmodify();
		while (true) { 
			String cmd=sc.nextLine();
			if(cmd.equals("1")) {
				String ujszerzo=sc.nextLine();
				books.get(a).setSzerzo(ujszerzo);
				break;
			}else if(cmd.equals("2")) {
				String ujcim=sc.nextLine();
				books.get(a).setName(cim);
				break;
			}else if(cmd.equals("3")) {
				int ujev=sc.nextInt();
				books.get(a).setKiadaseve(ujev);
				break;
			}	else if(cmd.equals("4")) {
			
					System.out.println("Adja meg a k�nyv �j c�m�t: ");
					String ujcim=sc.nextLine();
					books.get(a).setName(cim);
					System.out.println("Adja meg a k�nyv �j szerz�j�t: ");
					String ujszerzo=sc.nextLine();
					books.get(a).setSzerzo(ujszerzo);
					System.out.println("Adja meg a k�nyv �j kiad�si �v�t");
					int ujev=sc.nextInt();
					books.get(a).setKiadaseve(ujev);
					break;
			}
		}
		System.out.println("Sikeres m�dos�t�s");
	}	
}
	private static void kilistaz() {
		for(int i=0; i < books.size();i++) {
			System.out.println(books.get(i).toString());
			System.out.println();
		}
	}
	protected static void Booksearch() throws Exception  {
		Scanner sc=new Scanner(System.in);
		booksearch();
		while (true) {
			String cmd=sc.nextLine();
			
			if(cmd.equals("1")) {
				Collections.sort(books, new NameComparator());	
				kilistaz();
				break;
			}else if( cmd.equals("2")){
				Collections.sort(books, new AuthorComparator());
				kilistaz();
				break;
			}else if(cmd.equals("3")) {
				break;
			}
			
			}
		
		}
	
	/*
	 * Ez csak egy feleslegesen hossz� megold�sa a k�nyv hozz�ad�s�nak , de mivel a felhaszn�l�t nem tartjuk t�l okos l�nynek ennyire leg�san kellett kivitelezni ezt
	 */
	protected static void Letrehoz(List<K�nyvek> books) {
		Scanner sc=new Scanner(System.in);
		while (true) {
			String cmd=sc.nextLine();
			if(cmd.equals("1")) {
				System.out.print("K�rj�k adja meg a K�nyv c�m�t: ");
				String cim=sc.nextLine();
				System.out.print("K�rj�k adja meg a K�nyv szerz�j�t: ");
				String szerzo=sc.nextLine();
				
				System.out.print("K�rj�k adja meg a k�nyv m�faj�t: ");
				String mufaj=sc.nextLine();
				System.out.print("K�rj�k adja meg a k�nyv kiad�s�nak �v�t: ");
				int kiadaseve=sc.nextInt();
				
				books.add(new Irodalmi(cim,szerzo,kiadaseve,mufaj));
				System.out.println("K�nyv sikeresen hozz�adva");
				return;
			}else if(cmd.equals("2")) {
				System.out.print("K�rj�k adja meg a K�nyv c�m�t: ");
				String cim=sc.nextLine();
				System.out.print("K�rj�k adja meg a K�nyv szerz�j�t: ");
				String szerzo=sc.nextLine();
				System.out.print("K�rj�k adja meg a k�nyv tudom�ny�g�t:");
				String tudag=sc.nextLine();
				System.out.print("K�rj�k adja meg a k�nyv publik�ci�j�nak �vsz�m�t: ");
				int evszam=sc.nextInt();
				System.out.print("K�v�n le�r�st is hozz�adni?(igen/nem) ");
				Tudomanyos uj=new Tudomanyos(cim,szerzo,evszam,tudag);
				while (true) {
					String igaz=sc.nextLine();
					if(igaz.equals("igen")) {
						
						String leiras=sc.nextLine();
						uj.setLeiras(leiras);
						break;
					}else if(igaz.equals("nem")) {
						break;
					}	
				}
				
				books.add(uj);
				System.out.println("K�nyv sikeresen hozz�adva");
				break;
			}else if(cmd.equals("3")) {
				break;
			}
		}
	}
}
