package K�nyvt�r_nyilv�ntart�;

public class Tudomanyos extends K�nyvek {
	private String leiras;
	private String ag;//tudomanyag
	Tudomanyos(String name, String szerzo, int kiadaseve,String tudag) {
		super(name, szerzo, kiadaseve);
		// TODO Auto-generated constructor stub
		this.ag=tudag;
		leiras="M�g nincs hozz�adva le�r�s";
		this.type="t";
	}

	public void setLeiras(String s) {leiras=s;};
	public String getLeiras() {return leiras;}
	public String getAg() {return ag;}
	public void setAg(String ag) {this.ag=ag;}
	public String toString() {return super.toString()+", "+ag+", "+"Le�r�sa:"+ leiras;}
}
