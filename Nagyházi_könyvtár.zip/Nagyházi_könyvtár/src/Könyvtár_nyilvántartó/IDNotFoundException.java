package K�nyvt�r_nyilv�ntart�;

public class IDNotFoundException extends Exception{
	
	int id;
	IDNotFoundException(int a){
		id =a;
	}
	 public String getMessage() {
	    	return "Ilyen ID-val rendelkez� k�nyv nem tal�lhat�/nem m�dos�that� az elem a keresett halmazon. ";
	   }
}
