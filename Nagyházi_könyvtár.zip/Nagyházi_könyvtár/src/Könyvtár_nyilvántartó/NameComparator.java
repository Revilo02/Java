package K�nyvt�r_nyilv�ntart�;

import java.util.Comparator;

public class NameComparator implements Comparator<K�nyvek> {
	public int compare(K�nyvek b1, K�nyvek b2){
	return b1.getName().compareTo(b2.getName());
	}
}
