package Könyvtár_nyilvántartó;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
public class IO extends Parancsok {
	static void beolvas() throws Exception
	{  
		File file = new File("Demo.txt");

		try (	BufferedReader in = new BufferedReader( new InputStreamReader(new FileInputStream(file), "UTF8"))) {
		  String str;
		  
		  while ((str = in.readLine()) != null) {
			String [] sv=str.split(";") ;
			if(sv[0].equals("i")) {
			//	int a=(int)sv[3];
				
				try{
					Könyvek k=(new Irodalmi(sv[2],sv[3],Integer.parseInt(sv[4]),sv[5]));
					k.setID(Integer.parseInt(sv[1]));
					if(sv[6].equals("true")) {
						k.setKiadva(false);
					}else {
						k.setKiadva(true);
					}
					books.add(k);
				}   catch (Exception e) {
					  System.out.println(e.getMessage());
					  System.out.println("Nem megfelelő adattagok");}
				
				
				}
		    
		  }

		} catch (Exception e) {
		  System.out.println(e.getMessage());
		}
	}
	/*
	 * String mufaj;
	Irodalmi(String name, String szerzo, int kiadaseve,  String mufaj) ,
		super(name, szerzo, kiadaseve);
		this.mufaj=mufaj;
		type="i";
	}*/
}
