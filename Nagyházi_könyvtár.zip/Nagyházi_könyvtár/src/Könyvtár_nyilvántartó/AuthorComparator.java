package K�nyvt�r_nyilv�ntart�;

import java.util.Comparator;

public class AuthorComparator implements Comparator<K�nyvek> {
		public int compare(K�nyvek b1, K�nyvek b2){
		return b1.getSzerzo().compareTo(b2.getSzerzo());
		}
}
