package K�nyvt�r_nyilv�ntart�;

import java.util.Comparator;

public class IDComparator implements Comparator<K�nyvek> {
	public int compare(K�nyvek b1, K�nyvek b2){
		Double n1 = (double) b1.getID();
		Double n2 = (double) b2.getID();
	return n1.compareTo(n2);
	}
}